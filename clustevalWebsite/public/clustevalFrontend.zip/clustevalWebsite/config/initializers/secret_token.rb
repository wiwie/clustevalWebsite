# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ClustEval::Application.config.secret_token = 'c12e01130eaa1f245946ae8efb814dfb6913c4b22ba8a298421d88202802508cec11c03473200cbce811898608cc2870eda5b193c17b05ade85f7bb33a63c7a8'
