class ClustevalController < ApplicationController
	before_filter :authenticate
end
