class RepositoryTypesController < ApplicationController
	before_filter :require_user
end
