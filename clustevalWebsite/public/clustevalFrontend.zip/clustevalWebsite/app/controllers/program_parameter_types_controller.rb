class ProgramParameterTypesController < ApplicationController
	before_filter :require_user
end
