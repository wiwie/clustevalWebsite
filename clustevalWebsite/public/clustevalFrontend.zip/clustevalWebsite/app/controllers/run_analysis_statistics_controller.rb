class RunAnalysisStatisticsController < ApplicationController
	before_filter :require_user
end
