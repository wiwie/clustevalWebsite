class StatisticsRunsController < ApplicationController
	before_filter :require_user
end
