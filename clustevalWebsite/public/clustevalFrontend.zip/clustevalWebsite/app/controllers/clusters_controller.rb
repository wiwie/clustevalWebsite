class ClustersController < ApplicationController
	before_filter :require_user
end
