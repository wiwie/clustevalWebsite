class RunResultsAnalysesController < ApplicationController
	before_filter :require_user
end
