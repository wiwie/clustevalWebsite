class StatisticsController < ApplicationController
	before_filter :require_user
end
