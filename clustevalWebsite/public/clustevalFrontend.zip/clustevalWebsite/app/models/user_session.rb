class UserSession < Authlogic::Session::Base
end