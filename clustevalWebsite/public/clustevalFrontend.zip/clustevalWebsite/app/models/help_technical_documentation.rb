class HelpTechnicalDocumentation < ActiveRecord::Base
  # attr_accessible :title, :body
end
