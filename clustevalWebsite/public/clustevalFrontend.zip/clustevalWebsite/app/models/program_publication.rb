class ProgramPublication < ActiveRecord::Base
  attr_accessible :program_fullName, :program_publication, :program_publicationUrl
end
