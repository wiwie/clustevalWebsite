class RunRunDataAnalysisRunIdentifier < ActiveRecord::Base
  # attr_accessible :title, :body
end
