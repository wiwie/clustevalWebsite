class ProgramImage < ActiveRecord::Base
  attr_accessible :program_fullName, :program_imageUrl
end
