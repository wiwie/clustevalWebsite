class ProgramParameterType < ActiveRecord::Base
  attr_accessible :name
end
