class RunResultsProgramConfigsRanking < ActiveRecord::Base
  # attr_accessible :title, :body
end
