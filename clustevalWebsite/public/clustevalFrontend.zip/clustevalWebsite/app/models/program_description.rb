class ProgramDescription < ActiveRecord::Base
  attr_accessible :program_fullName, :program_description
end
