class Aboutu < ActiveRecord::Base
  # attr_accessible :title, :body
end
