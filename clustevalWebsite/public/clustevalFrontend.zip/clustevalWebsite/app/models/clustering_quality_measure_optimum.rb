class ClusteringQualityMeasureOptimum < ActiveRecord::Base
  attr_accessible :measure_name, :name
end
