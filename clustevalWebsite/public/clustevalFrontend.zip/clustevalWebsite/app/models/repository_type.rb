class RepositoryType < ActiveRecord::Base
  attr_accessible :id, :name
end
